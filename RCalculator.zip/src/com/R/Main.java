package com.R;

public class Main {

    public static void main(String[] args) {
        BMICalculator window = new BMICalculator();
        window.setVisible(true);
    }
}
